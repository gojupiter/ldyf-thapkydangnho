jQuery('#wpbody-content').ready(function($){
    $('.tc-admin-notice').show();
});