<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets__Tickets' );


	abstract class TribeEventsTickets extends Tribe__Tickets__Tickets {

	}