<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Tickets__Tickets_Handler' );


class Tribe__Events__Tickets__Tickets_Pro extends Tribe__Tickets__Tickets_Handler {}
