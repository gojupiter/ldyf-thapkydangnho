<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Tickets__Ticket_Object' );


class Tribe__Events__Tickets__Ticket_Object extends Tribe__Tickets__Ticket_Object {}
