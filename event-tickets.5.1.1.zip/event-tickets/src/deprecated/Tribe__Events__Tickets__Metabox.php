<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Tickets__Metabox' );


class Tribe__Events__Tickets__Metabox extends Tribe__Tickets__Metabox {}
