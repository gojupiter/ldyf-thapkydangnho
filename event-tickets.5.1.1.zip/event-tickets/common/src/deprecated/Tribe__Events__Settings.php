<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Settings.php' );

class Tribe__Events__Settings extends Tribe__Settings {}
