<?php
/**
 * Posts not found template
 */
?>
<h3 class="lastudio-posts__not-found"><?php esc_html_e( 'Posts not found', 'lastudio-elements' ); ?></h3>
