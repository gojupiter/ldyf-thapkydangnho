<?php
/**
 * Point item template
 */

$this->__render_point_content( $item_settings );
