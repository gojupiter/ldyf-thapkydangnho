<?php
/**
 * Timeline list start template
 */

$settings = $this->get_settings_for_display();
?>
<div class="lastudio-hor-timeline-list lastudio-hor-timeline-list--middle">
	<div class="lastudio-hor-timeline__line"></div>
